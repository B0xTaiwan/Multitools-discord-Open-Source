import os
import time
import random
import sqlite3
import subprocess
import fade
import requests

def get_interface():
    interface_text = """ 
                        

                        ████████▄   ▄█    █▄     ▄████████      ▀████    ▐████▀
                        ███   ▀███ ███    ███   ███    ███        ███▌   ████▀ 
                        ███    ███ ███    ███   ███    █▀          ███  ▐███   
                        ███    ███ ███    ███   ███                ▀███▄███▀   
                        ███    ███ ███    ███ ▀███████████         ████▀██▄    
                        ███    ███ ███    ███          ███        ▐███  ▀███   
                        ███   ▄███ ███    ███    ▄█    ███       ▄███     ███▄ 
                        ████████▀   ▀██████▀   ▄████████▀       ████       ███▄



          
                        ┏━━━━    Utils Tools      ━━━━┓      ┏━━━━    Osint Tools    ━━━━┓      ┏━━━━    Discord Tools    ━━━━┓
                        ┃ (01) Obfuscateur            ┃      ┃   (11) Osint Pseudo(dev)  ┃      ┃   (21) Mass report          ┃
                        ┃ (02) Ip Scanner(no working) ┃      ┃   (12) Osint Email(dev)   ┃      ┃   (22) Id to info           ┃
                          (03) Scrapper Web                      (13) DataBase                      (23) Gen Nitro
                          (04) Search DB(no working)             (14) IntelX(dev)                   (24) Mass DM Bot
                          (05) Ip info                           (15) Snusbase(key invalid)         (25) Webhook Spammer (dev)
                          (06) Pinger                            (16) N/A                 
                          (07) DDOS Tools                        (17) N/A                                   
                          (08) N/A                               (18) N/A                                    
                        ┃ (09) N/A                    ┃      ┃   (19) N/A                ┃      ┃                             ┃
                        ┃ (10) Leave                  ┃      ┃   (20) N/A                ┃      ┃                             ┃
                        ┗━━━━                     ━━━━┛      ┗━━━━                   ━━━━┛      ┗━━━━                     ━━━━┛
    """
    return fade.purplepink(interface_text)

def ip_scanner():
    os.system("cls")
    ip = input("Entrez l'IP à scanner: ")
    print(f"Scanning IP {ip}... terminé.")

def web_scraper():
    os.system("cls")
    url = input("Entrez l'URL à scraper: ")
    print(f"Scraping {url}... terminé.")

def webhook_spammer():
    os.system("cls")
    webhook_url = input("Entrez l'URL du webhook: ")
    message = input("Entrez le message à envoyer: ")
    count = int(input("Combien de fois voulez-vous envoyer le message? "))

    for i in range(count):
        response = requests.post(webhook_url, json={"content": message})
        if response.status_code == 204:
            print(f"Message {i+1}/{count} envoyé avec succès.")
        else:
            print(f"Échec de l'envoi du message {i+1}: {response.status_code}")
        time.sleep(1)  

def search_user_by_discord_id():
    os.system("cls")
    database_path = input("Entrez le chemin de la base de données : ")
    discord_id = input("Entrez l'ID Discord à rechercher : ")
    
    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()

    query = "SELECT * FROM users WHERE discord_id = ?"
    cursor.execute(query, (discord_id,))

    result = cursor.fetchone()

    conn.close()

    if result:
        print(f"User found: {result}")
    else:
        print("No user found with that Discord ID.")

def osint_via_pseudo():
    os.system("cls")
    pseudo = input("Entrez le pseudonyme à rechercher : ")
    print(f"Recherche OSINT pour le pseudo : {pseudo}")

    osint_sites = [
        f"https://www.google.com/search?q={pseudo}",
        f"https://www.bing.com/search?q={pseudo}",
        f"https://search.yahoo.com/search?p={pseudo}",
        f"https://duckduckgo.com/?q={pseudo}",
        f"https://www.reddit.com/search/?q={pseudo}",
        f"https://www.github.com/search?q={pseudo}",
        f"https://www.twitter.com/search?q={pseudo}",
        f"https://www.instagram.com/{pseudo}",
        f"https://www.linkedin.com/search/results/all/?keywords={pseudo}",
        f"https://www.tiktok.com/search?q={pseudo}",
        f"https://www.pinterest.com/search/pins/?q={pseudo}",
        f"https://www.tumblr.com/search/{pseudo}",
        f"https://stackoverflow.com/search?q={pseudo}",
        f"https://www.deviantart.com/search?q={pseudo}",
        f"https://www.quora.com/search?q={pseudo}",
        f"https://www.medium.com/search?q={pseudo}",
        f"https://{pseudo}.onion", 
        f"https://www.dark.fail/search?q={pseudo}",
        f"https://www.pipl.com/search/?q={pseudo}",
        f"https://haveibeenpwned.com/unifiedsearch/{pseudo}",
        f"https://www.spokeo.com/{pseudo}",
        f"https://www.peekyou.com/{pseudo}",
        f"https://www.pastebin.com/search?q={pseudo}",
        f"https://scylla.sh/search?q={pseudo}",
        f"https://www.twitch.tv/search?term={pseudo}",
        f"https://www.soundcloud.com/search?q={pseudo}",
        f"https://www.last.fm/search?q={pseudo}",
        f"https://myspace.com/search?q={pseudo}"
    ]

    print(f"\nSites à vérifier pour {pseudo} :\n")

    for site in osint_sites:
        print(f"- {site}")

    input("\nAppuyez sur Entrée pour revenir au menu...")

def osint_via_email():
    os.system("cls")
    email = input("Entrez l'email à rechercher : ")
    print(f"Recherche OSINT pour l'email : {email}")

    email_osint_sites = [
        f"https://www.google.com/search?q={email}",
        f"https://www.bing.com/search?q={email}",
        f"https://search.yahoo.com/search?p={email}",
        f"https://duckduckgo.com/?q={email}",
        f"https://haveibeenpwned.com/unifiedsearch/{email}",
        f"https://emailrep.io/{email}",
        f"https://hunter.io/search?q={email}",
        f"https://www.pipl.com/search/?q={email}",
        f"https://verify-email.org/home/verify-as-guest/{email}",
        f"https://email-checker.net/check?email={email}",
        f"https://www.spokeo.com/{email}",
        f"https://www.peekyou.com/{email}",
        f"https://www.thatsthem.com/email/{email}",
        f"https://emailveritas.com/?q={email}"
    ]

    print(f"\nSites à vérifier pour {email} :\n")

    for site in email_osint_sites:
        print(f"- {site}")

    input("\nAppuyez sur Entrée pour revenir au menu...")

def menu():
    os.system("cls")
    print(get_interface())

def main():
    while True:
        menu()
        choix = input("Sélectionnez une option: ")

        if choix == "1":
            os.system("cls")  
            subprocess.run(['python', 'program\\obfuscator.py'])
        elif choix == "2":
            os.system("cls")  
            ip_scanner()
        elif choix == "3":
            os.system("cls")  
            web_scraper()
        elif choix == "4":
            os.system("cls")
            search_user_by_discord_id()
        elif choix == "5":
            os.system("cls")
            subprocess.run(['python', 'program\\ipinfo.py'])
        elif choix == "6":
            os.system("cls")
            subprocess.run(['python', 'program\\ippinger.py'])
        elif choix == "7":
            os.system ("cls")
            subprocess.run(['python', 'program\\ddos.py'])
        elif choix == "15":
            os.system ("cls")
            subprocess.run(['python', 'program\\snusbase.py'])
        elif choix == "25":
            os.system("cls")
            webhook_spammer()
        elif choix == "11":
            os.system("cls")
            osint_via_pseudo()
        elif choix == "12":
            os.system("cls")
            osint_via_email()
        elif choix == "13":
            os.system("cls")
            subprocess.run(['python', 'program\\database.py'])
        elif choix == "14":
            os.system("cls")
            subprocess.run(['python', 'program\\intelx.py'])
        elif choix == "21":
            os.system ("cls")
            subprocess.run(['python', 'program\\massreport.py'])
        elif choix == "22":
            os.system("cls")
            subprocess.run(['python', 'program\\idinfo.py'])
        elif choix == "23":
            os.system("cls")
            subprocess.run(['python', 'program\\nitrogen.py'])
        elif choix == "24":
            os.system("cls")
            subprocess.run(['python', 'program\\dmall.py'])
        elif choix == "10":
            os.system("cls")   
            print("Quitter...")
            break
        else:  
            print("Entrée incorrecte, essayez encore.")

main()
