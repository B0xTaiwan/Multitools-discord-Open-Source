import discord
import asyncio
import fade
from colorama import Fore, Style

intents = discord.Intents.default()
intents.members = True
client = discord.Client(intents=intents)

RED = "\033[91m"
RESET = "\033[0m"

print(Fore.CYAN + """
████████▄    ▄▄▄▄███▄▄▄▄      ▄████████  ▄█        ▄█      
███   ▀███ ▄██▀▀▀███▀▀▀██▄   ███    ███ ███       ███      
███    ███ ███   ███   ███   ███    ███ ███       ███      
███    ███ ███   ███   ███   ███    ███ ███       ███      
███    ███ ███   ███   ███ ▀███████████ ███       ███      
███    ███ ███   ███   ███   ███    ███ ███       ███      
███   ▄███ ███   ███   ███   ███    ███ ███▌    ▄ ███▌    ▄
████████▀   ▀█   ███   █▀    ███    █▀  █████▄▄██ █████▄▄██
                                        ▀         ▀     
""" + RESET)

async def send_message_to_all(message):
    
    if not client.guilds:
        print("Le bot n'est pas dans de guildes.")
        return

    guild = client.guilds[0]
    for member in guild.members:
        if not member.bot:
            try:
                await member.send(message)
                print(f'J\'ai envoyé le message a {member.name}')
            except Exception as e:
                print(f'ai pas pu envoyer le message a{member.name}: {e}')
        await asyncio.sleep(1)  

@client.event
async def on_ready():
    print(f'Je suis co à {client.user}')
    while True:
        message_to_send = input(Fore.BLUE + "Abrège frère : " + Style.RESET_ALL)
        await send_message_to_all(message_to_send)

if __name__ == "__main__":
    token = input(Fore.BLUE + "Entre le token de ton Bot je vais pas le voler : " + Style.RESET_ALL)
    client.run(token)
