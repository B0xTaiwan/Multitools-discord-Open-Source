import sys
import json
import traceback
import datetime
import requests
import os
from PyQt5 import QtWidgets, QtGui, QtCore

snusbase_auth = 'sbyjthkoft4yaimbwcjqpmxs8huovd'
snusbase_api = 'https://api-experimental.snusbase.com/'

class ResultWindow(QtWidgets.QWidget):
    def __init__(self, results):
        super().__init__()
        self.setWindowTitle("Résultats de la recherche")
        self.setGeometry(200, 200, 600, 400)
        self.initUI(results)

    def initUI(self, results):
        layout = QtWidgets.QVBoxLayout()
        
        result_label = QtWidgets.QLabel(self.tr("Résultats :"))
        result_label.setStyleSheet("font-size: 16px; font-weight: bold; font-family: 'Roboto';")
        layout.addWidget(result_label)
        
        self.result_area = QtWidgets.QTextEdit(self)
        self.result_area.setReadOnly(True)
        self.result_area.setText(results)
        self.result_area.setStyleSheet("font-family: 'Roboto'; font-weight: bold;")
        layout.addWidget(self.result_area)
        
        self.setLayout(layout)

class HeaderWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        layout = QtWidgets.QHBoxLayout()

        # Create "Created By ΛZMΛ" label with emoji
        creator_label = QtWidgets.QLabel("Created By BeX3l")
        creator_label.setStyleSheet("font-size: 14px; font-weight: bold; font-family: 'Roboto'; color: black;")
        layout.addWidget(creator_label)

        # Spacer to push the language button to the right
        spacer = QtWidgets.QSpacerItem(40, 20, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Minimum)
        layout.addItem(spacer)

        # Create Language button
        self.language_button = QtWidgets.QPushButton("🌐 Language")
        self.language_button.setStyleSheet("""
        QPushButton {
            background-color: #4CAF50;
            font-size: 14px;
            font-weight: bold;
            color: white;
            border-radius: 10px;
            padding: 10px;
            font-family: 'Roboto';
            border: 2px solid #388E3C;
        }
        QPushButton:hover {
            background-color: #45A049;
        }
        QPushButton:pressed {
            background-color: #2E7D32;
        }
        """)
        self.language_button.setMenu(self.create_language_menu())
        layout.addWidget(self.language_button)

        self.setLayout(layout)

    def create_language_menu(self):
        menu = QtWidgets.QMenu(self)

        french_action = QtWidgets.QAction("Français", self)
        french_action.triggered.connect(lambda: self.change_language('fr'))
        menu.addAction(french_action)

        english_action = QtWidgets.QAction("English", self)
        english_action.triggered.connect(lambda: self.change_language('en'))
        menu.addAction(english_action)

        return menu

    def change_language(self, language_code):
        self.parent().set_language(language_code)

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.language_code = 'en'  # Default language
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.tr("Recherche VirtualTool"))
        self.setGeometry(100, 100, 800, 600)
        self.setFixedSize(800, 600)

        # Set GIF background
        self.movie = QtGui.QMovie("background.jpg")
        self.movie.frameChanged.connect(self.repaint)
        self.movie.start()

        # Create HeaderWidget and add it to the main window
        self.header_widget = HeaderWidget(self)
        self.setMenuWidget(self.header_widget)  # Adds HeaderWidget to the top of the window

        # Create buttons with emojis and styles
        self.create_buttons()

    def create_buttons(self):
        button_style = """
        QPushButton {
            background-color: #1E90FF;
            font-size: 16px;
            font-weight: bold;
            color: white;
            border-radius: 20px;
            padding: 10px;
            font-family: 'Roboto';
            border: 2px solid #1C86EE;
            box-shadow: 3px 3px 5px #888888;
        }
        QPushButton:hover {
            background-color: #63B8FF;
        }
        QPushButton:pressed {
            background-color: #1874CD;
        }
        """

        self.btn_email = QtWidgets.QPushButton(self.tr("✉️ Rechercher avec une Email"), self)
        self.btn_email.setGeometry(QtCore.QRect(150, 100, 500, 40))
        self.btn_email.setStyleSheet(button_style)
        self.btn_email.setIcon(QtGui.QIcon("email_icon.png"))
        self.btn_email.clicked.connect(self.api_email)

        self.btn_username = QtWidgets.QPushButton(self.tr("👤 Rechercher avec un pseudo"), self)
        self.btn_username.setGeometry(QtCore.QRect(150, 150, 500, 40))
        self.btn_username.setStyleSheet(button_style)
        self.btn_username.setIcon(QtGui.QIcon("username_icon.png"))
        self.btn_username.clicked.connect(self.api_username)

        self.btn_ip = QtWidgets.QPushButton(self.tr("🌐 Rechercher via une Adresse IP"), self)
        self.btn_ip.setGeometry(QtCore.QRect(150, 200, 500, 40))
        self.btn_ip.setStyleSheet(button_style)
        self.btn_ip.setIcon(QtGui.QIcon("ip_icon.png"))
        self.btn_ip.clicked.connect(self.api_ip)

        self.btn_ip_whois = QtWidgets.QPushButton(self.tr("🔍 Whois une Adresse IP"), self)
        self.btn_ip_whois.setGeometry(QtCore.QRect(150, 250, 500, 40))
        self.btn_ip_whois.setStyleSheet(button_style)
        self.btn_ip_whois.setIcon(QtGui.QIcon("whois_icon.png"))
        self.btn_ip_whois.clicked.connect(self.api_ip_whois)

        self.btn_password = QtWidgets.QPushButton(self.tr("🔑 Rechercher par un mot-de-passe"), self)
        self.btn_password.setGeometry(QtCore.QRect(150, 300, 500, 40))
        self.btn_password.setStyleSheet(button_style)
        self.btn_password.setIcon(QtGui.QIcon("password_icon.png"))
        self.btn_password.clicked.connect(self.api_password)

        self.btn_hash = QtWidgets.QPushButton(self.tr("🔐 Rechercher avec un mot de passe Hasher"), self)
        self.btn_hash.setGeometry(QtCore.QRect(150, 350, 500, 40))
        self.btn_hash.setStyleSheet(button_style)
        self.btn_hash.setIcon(QtGui.QIcon("hash_icon.png"))
        self.btn_hash.clicked.connect(self.api_hash)

        self.btn_combo = QtWidgets.QPushButton(self.tr("🔗 Rechercher avec Combo"), self)
        self.btn_combo.setGeometry(QtCore.QRect(150, 400, 500, 40))
        self.btn_combo.setStyleSheet(button_style)
        self.btn_combo.setIcon(QtGui.QIcon("combo_icon.png"))
        self.btn_combo.clicked.connect(self.api_combo)

        self.btn_name = QtWidgets.QPushButton(self.tr("📛 Rechercher avec Prenom & Nom"), self)
        self.btn_name.setGeometry(QtCore.QRect(150, 450, 500, 40))
        self.btn_name.setStyleSheet(button_style)
        self.btn_name.setIcon(QtGui.QIcon("name_icon.png"))
        self.btn_name.clicked.connect(self.api_name)

    def set_language(self, language_code):
        self.language_code = language_code
        translations = {
            'en': {
                "Recherche VirtualTool": "VirtualTool Search",
                "✉️ Rechercher avec une Email": "✉️ Search with Email",
                "👤 Rechercher avec un pseudo": "👤 Search with Username",
                "🌐 Rechercher via une Adresse IP": "🌐 Search with IP Address",
                "🔍 Whois une Adresse IP": "🔍 Whois IP Address",
                "🔑 Rechercher par un mot-de-passe": "🔑 Search by Password",
                "🔐 Rechercher avec un mot de passe Hasher": "🔐 Search with Password Hash",
                "🔗 Rechercher avec Combo": "🔗 Search with Combo",
                "📛 Rechercher avec Prenom & Nom": "📛 Search with First & Last Name",
                "Résultats :": "Results :",
                "Language button clicked!": "Language button clicked!"
            },
            'fr': {
                "Recherche VirtualTool": "Recherche VirtualTool",
                "✉️ Rechercher avec une Email": "✉️ Rechercher avec une Email",
                "👤 Rechercher avec un pseudo": "👤 Rechercher avec un pseudo",
                "🌐 Rechercher via une Adresse IP": "🌐 Rechercher via une Adresse IP",
                "🔍 Whois une Adresse IP": "🔍 Whois une Adresse IP",
                "🔑 Rechercher par un mot-de-passe": "🔑 Rechercher par un mot-de-passe",
                "🔐 Rechercher avec un mot de passe Hasher": "🔐 Rechercher avec un mot de passe Hasher",
                "🔗 Rechercher avec Combo": "🔗 Rechercher avec Combo",
                "📛 Rechercher avec Prenom & Nom": "📛 Rechercher avec Prenom & Nom",
                "Résultats :": "Résultats :",
                "Language button clicked!": "Bouton Langue cliqué !"
            }
        }

        translation = translations.get(self.language_code, translations['en'])

        self.setWindowTitle(translation["Recherche VirtualTool"])

        self.btn_email.setText(translation["✉️ Rechercher avec une Email"])
        self.btn_username.setText(translation["👤 Rechercher avec un pseudo"])
        self.btn_ip.setText(translation["🌐 Rechercher via une Adresse IP"])
        self.btn_ip_whois.setText(translation["🔍 Whois une Adresse IP"])
        self.btn_password.setText(translation["🔑 Rechercher par un mot-de-passe"])
        self.btn_hash.setText(translation["🔐 Rechercher avec un mot de passe Hasher"])
        self.btn_combo.setText(translation["🔗 Rechercher avec Combo"])
        self.btn_name.setText(translation["📛 Rechercher avec Prenom & Nom"])

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        frame = self.movie.currentPixmap()
        painter.drawPixmap(self.rect(), frame)

    def api_email(self):
        self.show_input_dialog(self.tr("Email"), "email")

    def api_username(self):
        self.show_input_dialog(self.tr("Username"), "username")

    def api_ip(self):
        self.show_input_dialog(self.tr("IP"), "lastip")

    def api_ip_whois(self):
        self.show_input_dialog(self.tr("IP Whois"), "whois")

    def api_password(self):
        self.show_input_dialog(self.tr("Password"), "password")

    def api_hash(self):
        self.show_input_dialog(self.tr("Hash"), "hash")

    def api_combo(self):
        self.show_input_dialog(self.tr("Combo"), "combo")

    def api_name(self):
        self.show_input_dialog(self.tr("Name"), "name")

    def show_input_dialog(self, label, search_type):
        dialog = InputDialog(label, search_type, self)
        dialog.exec_()

    def search_snusbase(self, search_type, term):
        try:
            response = requests.post(snusbase_api + 'data/search', headers={
                'Auth': snusbase_auth,
                'Content-Type': 'application/json'
            }, json={
                'terms': [term],
                'types': [search_type],
                'wildcard': False
            })
            if response.status_code == 200:
                results = response.json()
                self.show_results(json.dumps(results, indent=2))
            else:
                self.show_results(self.tr("La requête a échoué."))
        except Exception as e:
            self.handle_error(e)

    def api_whois(self, auth_token, ip):
        try:
            response = requests.get(f"https://beta.snusbase.com/v1/whois/{ip}", headers={
                "authorization": auth_token
            })
            if response.status_code == 200:
                result = response.json()
                self.show_results(json.dumps(result, indent=2))
            else:
                self.show_results(self.tr("La requête a échoué."))
        except Exception as e:
            self.handle_error(e)

    def show_results(self, results):
        self.result_window = ResultWindow(results)
        self.result_window.show()

    def handle_error(self, error):
        error_message = traceback.format_exc()
        now = datetime.datetime.now()
        timestamp = now.strftime("%Y-%m-%d_%H-%M-%S")
        log_directory = self.create_directory("logs")
        log_file = os.path.join(log_directory, f"error_{timestamp}.log")
        with open(log_file, "w") as file:
            file.write(str(error_message))
        self.show_results(self.tr("Une erreur s'est produite. Veuillez consulter les logs pour plus de détails."))

    def create_directory(self, category):
        directory = f"./resource/{category}"
        if not os.path.exists(directory):
            os.makedirs(directory)
        return directory

class InputDialog(QtWidgets.QDialog):
    def __init__(self, label, search_type, parent=None):
        super().__init__(parent)
        self.label = label
        self.search_type = search_type
        self.parent = parent
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.tr(f"Entrer {self.label}"))
        self.setGeometry(300, 300, 400, 200)

        # Set GIF background
        self.movie = QtGui.QMovie("dialog_background.gif")
        self.movie.frameChanged.connect(self.repaint)
        self.movie.start()

        layout = QtWidgets.QVBoxLayout()

        input_label = QtWidgets.QLabel(self.tr(f"Entrez {self.label} :"))
        input_label.setStyleSheet("font-size: 14px; font-weight: bold; font-family: 'Roboto';")
        layout.addWidget(input_label)

        self.input_field = QtWidgets.QLineEdit(self)
        self.input_field.setStyleSheet("font-family: 'Roboto'; font-weight: bold;")
        layout.addWidget(self.input_field)

        button_layout = QtWidgets.QHBoxLayout()
        
        ok_button = QtWidgets.QPushButton(self.tr("OK"))
        ok_button.clicked.connect(self.handle_ok)
        ok_button.setStyleSheet("font-family: 'Roboto'; font-weight: bold;")
        button_layout.addWidget(ok_button)

        cancel_button = QtWidgets.QPushButton(self.tr("Annuler"))
        cancel_button.clicked.connect(self.reject)
        cancel_button.setStyleSheet("font-family: 'Roboto'; font-weight: bold;")
        button_layout.addWidget(cancel_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def paintEvent(self, event):
        painter = QtGui.QPainter(self)
        frame = self.movie.currentPixmap()
        painter.drawPixmap(self.rect(), frame)

    def handle_ok(self):
        term = self.input_field.text()
        if self.search_type == "whois":
            self.parent.api_whois(snusbase_auth, term)
        else:
            self.parent.search_snusbase(self.search_type, term)
        self.accept()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    mainWindow = MainWindow()
    mainWindow.show()
    sys.exit(app.exec_())