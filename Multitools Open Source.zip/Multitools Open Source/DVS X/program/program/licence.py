import fade
import os

def get_interface():
    interface_text = """
 ▄█        ▄█   ▄████████    ▄████████ ███▄▄▄▄    ▄████████    ▄████████       ┃
███       ███  ███    ███   ███    ███ ███▀▀▀██▄ ███    ███   ███    ███       ┃ IntelX tools created by Azma x AltF4 on discord
███       ███▌ ███    █▀    ███    █▀  ███   ███ ███    █▀    ███    █▀        ┃ 
███       ███▌ ███         ▄███▄▄▄     ███   ███ ███         ▄███▄▄▄           ┃ This discord server: [discord.gg/hezbollahh] and [discord.gg/ovek]
███       ███▌ ███        ▀▀███▀▀▀     ███   ███ ███        ▀▀███▀▀▀           ┃
███       ███  ███    █▄    ███    █▄  ███   ███ ███    █▄    ███    █▄        ┃ For educative purposes
███▌    ▄ ███  ███    ███   ███    ███ ███   ███ ███    ███   ███    ███       ┃
█████▄▄██ █▀   ████████▀    ██████████  ▀█   █▀  ████████▀    ██████████ 
▀                                                                        
                ╔══════════════════════════════╗
                ║                              ║
                ║      (1) Back to intelX      ║
                ║                              ║
                ╚══════════════════════════════╝
""" 
    print(fade.purplepink(interface_text))

    choice = input('┌───(Hezbollah)─[~/IntelX/Licence]\n└──$')

    if choice == '1':
        back()
    else:
        print("Erreur: choix invalide")

def back():
    os.system('python intelx.py')

def main():
    get_interface()

main()