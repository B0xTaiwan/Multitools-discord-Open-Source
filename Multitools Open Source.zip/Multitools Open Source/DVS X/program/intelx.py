import os
import time
import requests
import subprocess
import fade
from pystyle import *

white = Col.white
red = Col.red
green = Col.green
black = Col.black
blue = Col.blue
yellow = Col.yellow
turquoise = Col.turquoise
cyan = Col.cyan
gray = Col.gray
orange = Col.orange
pink = Col.pink
rainbow = Col.rainbow

class IntelX:
    def __init__(self, key):
        self.url = "https://2.intelx.io/"
        self.key = key
        self.agent = 'IX-Python/0.5'

    def search(self, term, max=100):
        headers = {'x-key': self.key, 'User-Agent': self.agent}
        data = {"term": term, "maxresults": max, "lookuplevel": 0}
        
        res = requests.post(f"{self.url}/intelligent/search", headers=headers, json=data)
        
        if res.status_code == 200:
            try:
                data = res.json()
                sid = data.get('id')
                print(fade.purplepink(f"id : {sid}"))
                return self.results(sid, max)
            except ValueError:
                print(fade.purplepink("Erreur lors du décodage JSON"))
                print(fade.purplepink(f"Réponse brute : {res.text}"))
        else:
            print(fade.purplepink(f"Erreur HTTP : {res.status_code}"))
            print(fade.purplepink(f"Réponse brute : {res.text}"))

    def results(self, sid, max):
        headers = {'x-key': self.key, 'User-Agent': self.agent}
        
        while True:
            time.sleep(1)
            res = requests.get(f"{self.url}/intelligent/search/result?id={sid}&limit={max}", headers=headers)
            if res.status_code == 200:
                data = res.json()
                if data['status'] in [1, 2]:
                    return data['records']
            else:
                print(fade.purplepink(f"Erreur lors de la récupération des résultats : {res.status_code}"))
                print(fade.purplepink(f"Réponse brute : {res.text}"))

def get_interface():
    interface_text = """
             ▄█
            ███  ███▄▄▄▄       ███        ▄████████  ▄█       ▀████    ▐████▀
            ███  ███▀▀▀██▄ ▀█████████▄   ███    ███ ███         ███▌   ████▀
            ███▌ ███   ███    ▀███▀▀██   ███    █▀  ███          ███  ▐███
            ███▌ ███   ███     ███   ▀  ▄███▄▄▄     ███          ▀███▄███▀
            ███▌ ███   ███     ███     ▀▀███▀▀▀     ███          ████▀██▄
            ███▌ ███   ███     ███       ███    █▄  ███         ▐███  ▀███
            ███  ███   ███     ███       ███    ███ ███▌    ▄  ▄███     ███▄
            ███   ▀█   █▀     ▄████▀     ██████████ █████▄▄██ █████      ███▄
            █▀ 
                               ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
                               ┃                           ┃
                               ┃    (1) Search IntelX      ┃
                               ┃    (2) Back to Y-HZB      ┃
                               ┃    (3) Licence intelX     ┃
                               ┃                           ┃
                               ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
                               

    """
    return fade.purplepink(interface_text)

def save_results(term, results):
    if not os.path.exists('results'):
        os.makedirs('results')
    filename = os.path.join('results', f"{term}.txt")
    with open(filename, 'w', encoding='utf-8') as file:
        for r in results:
            file.write(f"{r}\n")
    print(fade.purplepink(f"Les résultats ont été enregistrés dans le fichier {filename}"))

def back():
    os.system('python main.py')

def main():
    os.system("cls" if os.name == "nt" else "clear")
    print(get_interface())
    key = "f9f2787f-a9e9-47a9-9f60-8fa15f7dd926"
    ix = IntelX(key)

    while True:
        choix = input("┌───(Hezbollah)─[~/IntelX/Searcher]\n└──$ ")
        
        if choix == '1':
            term = input("Entrez le terme à rechercher : ")
            if term.lower() == 'exit':
                print("Fin du programme.")
                break
            res = ix.search(term)
            if res:
                save_results(term, res)
                for r in res:
                    print(r)
        elif choix == '2': 
            os.system("python .yzbh\main.py")
        elif choix == '3':
            os.system("cls")
            subprocess.run(['python', 'program\\licence.py'])
            break
        else:
            print("Option invalide. Veuillez choisir 1 ou 2.")

if __name__ == "__main__":
    main()
